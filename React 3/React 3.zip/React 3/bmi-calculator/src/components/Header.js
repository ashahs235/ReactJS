export function Header()
{
    //code formatter - extensions > prettier formatter
    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
            <div className="w-100 text-center text-light h2">
                <center>BMI Calculator</center>

            </div>
        </nav>

    )
}

