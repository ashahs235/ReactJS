//hook import always on top
import {useState} from "react";

import "./BMICalculator.css";

export function BMICalculator() //old - class based syntax, now Hooks based syntax
{
    //const [weight] = useState(""); // "" - error in console bcoz no value, this value is stored in <input value
    const [weight, updateWeightValue] = useState("");

    const [height, updateHeightValue] = useState("");

    const [age, updateAgeValue] = useState("");

    const [bmiValue, updateBMIValue] = useState(null); //0
    
    function calculateBMIValue()
    {
        //console.log("Button Clicked", weight);
         console.log("Button Clicked", weight, height, age);
         const heightInMeters = height/100;
         const bmiValue = weight/(heightInMeters * heightInMeters);
         console.log("BMI Value", bmiValue);
         const roundedOffBMIValue = bmiValue.toFixed(2);

         updateBMIValue(roundedOffBMIValue);

         console.log("BMI Value", roundedOffBMIValue);
        
    }

    function handleWeightInputChange(e)
    {
        //onChange internally passes an event e, type anything in textbox - but empty
        //internally a event is triggered - synthetic based event - target - value in console
        //console.log(e); // above 2 points
        console.log(e.target.value); //value entered in textbox is printed in console not in form field bcoz value={weight} const [weight] = useState(""); 
        console.log("weight value before update is", weight, "target", e.target.value); //weight = ""
        updateWeightValue(e.target.value); //value can enter in textbox
    }

    function handleHeightInputChange(e)
    {
        updateHeightValue(e.target.value);
    }

    function handleAgeInputChange(e)
    {
        updateAgeValue(e.target.value);
    }

    function displayBMIValue()
    {
        if(bmiValue !== null)
        {
            return(
                <div>
                    BMI value is {bmiValue}
                </div>
            );
        }
    }

    return(
        <div className="container d-flex flex-column form-container">
            <div>
                <label className="me-4 mt-5">Weight in kgs :</label>
                {/* <input type="text"></input> */}

                {/* warning to use onChange*/}
                {/* <input type="text" value={weight}></input> */}

                {/* onChange attribute for value */}
                <input type="text"
                    value={weight} onChange={handleWeightInputChange}
                ></input>
            </div>
            <div>
                <label className="me-4 mt-5">Height in cms :</label>
                {/* <input type="text"></input>  */}
                {/* value = "",  value={} bcoz variable is passed */}
                <input type="text" value={height} onChange={handleHeightInputChange}></input>   
                {/* onChange={(event) => handleHeightInputChange(event)} */}
            </div>

            <div>
            <label className="me-4 mt-5">Age :</label>
                <input type="text" value={age} onChange={handleAgeInputChange}/>
            </div>

            <br></br>
            <button type="button" 
                className="btn btn-primary mt-4"
                onClick={calculateBMIValue}>
                Calculate BMI
            </button>
            {/* <div>The BMI value is : {bmiValue}</div> */}
            {/* functions within JSX */}
            {displayBMIValue()}
        </div>
    );
}