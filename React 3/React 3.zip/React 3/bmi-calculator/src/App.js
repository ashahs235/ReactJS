import './App.css';
import {Header} from "./components/Header.js";
import {BMICalculator} from "./components/BMICalculator.js"

function App() {
  return (
    <div className="App">
      <Header/>
      <BMICalculator />
    </div>
  );
}

export default App;
