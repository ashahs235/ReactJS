//Parent Component - Complex project splitting - Flipkart - many moving parts

import './App.css';
import {DisplayStudentsName, someVar} from './components/DisplayStudentsName.js';
import {DisplayClassInformation} from './components/DisplayClassInformation.js';

//export default
//import DisplayClassInformation from './components/DisplayClassInformation.js';

// function App() {
//   //const userName = "Developer"; //cut it & paste in DisplayStudentsName.js
//   return (
//     <div className="App">
//       {/* <div>Name is {userName}</div>  //cut this too */}
//     </div>
//   );
// }

//We usually dont write anything in app.js bcoz it's an entry component, create another component, modularize code

//invoke  <DisplayStudentsName/> designaton is an attribute & can be anything - key value pair
//designation is a prop value - prop is a key value pair
//designation="Developer" => equal to sign is passed as an object in child component internally
//control hover/control click on <DisplayClassInformation />

function App() {
  console.log(someVar);
  return (
    <div className="App">
      <DisplayClassInformation topicOfClass="MERN Stack"/>
      <div className="student-info">
        {/* <DisplayStudentsName/>
        <DisplayStudentsName/>
        <DisplayStudentsName/> */}
        <DisplayStudentsName designation="Developer" salary="25000"/>
        <DisplayStudentsName designation="Tester" salary="15000" />
        <DisplayStudentsName designation="Support" />
      </div>
    </div>
  );
}

export default App;
