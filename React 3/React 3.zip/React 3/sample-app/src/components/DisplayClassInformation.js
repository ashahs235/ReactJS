export function DisplayClassInformation(props)
{
    //console.log(props); //comment props in DisplayStudentsName
    return (
        <div><h1>Full Stack Development Classes</h1>
         <div>{props.topicOfClass}</div>
         </div>
    );
}