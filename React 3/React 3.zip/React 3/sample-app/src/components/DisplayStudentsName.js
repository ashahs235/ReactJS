import "./DisplayStudentsName.css";

//PROPS - passing data from parent component to child component - changing the usernames
//props is a parameter in child component, props is an object
//attributes of DisplayStudentsName component in parent is passed as a built in parameter to that child component with a name props
//React internally sends an object called props - JSON


//Child Component
export function DisplayStudentsName(props)
{
    console.log("The prop value passed from parent Component is", props);
    //const propValue = props
    //Component 
    //const userName = "Developer"; //--(1) //remove for props while writing in parent component
    const technology = "ReactJS";
    return (
    <div className="student-card">
        {/* //--(1) below */}
        {/* <div>Designation is {userName}</div>  */}
        <div>Job roles are {props.designation}, {props.salary}</div>
        <div>Salaries are {props.salary}</div>
        <div>Skills : {technology}</div>
    </div>
    );
}

//Internally DisplayStudentsName({designation: "Developer", salary: "25000"}) function is called
// const props = {designation: "Developer", salary: "25000"};
// DisplayStudentsName(props);

//another way - remove export keyword from above & 
//export default DisplayStudentsName;  => no {} in importing file bcoz
//export default meaning is the only component needs to be exported as a default value

export const someVar = 12;

//exporting multiple functions - so export default is not preferred bcoz of multiple exports