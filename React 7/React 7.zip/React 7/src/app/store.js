import { configureStore } from '@reduxjs/toolkit';
//step 1 : import Reducer
import counterReducer from '../features/counter/counterSlice';
import characterReducer from "../features/characterList/characterNameSlice";


//Step 2 : Pass the reducer to store
export const store = configureStore({
  reducer: {
    counter: counterReducer, //LHS is name of the reducer
    character : characterReducer, //RHS is d imported reducer -- this is d step where data gets stored
  },
});
