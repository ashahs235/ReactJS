import React, { useState } from 'react';

//Step 1 : import useSelector hook from "react-redux" package
//step 1 for updating values : import useDispatch hook from "react-redux" pkg
import { useSelector, useDispatch } from 'react-redux';

//update values from reducer
//import actions from Slice
import {
  decrement,
  increment,
  incrementByAmount,
  incrementAsync,
  incrementIfOdd,
  //selectCount, --removed
} from './counterSlice';
import styles from './Counter.module.css';

export function Counter() {
  //const count = useSelector(selectCount); --removed

  //step 2 : write a variable name & get the value of initialState variable from useSelector hook
  //useSelector hook
  //state is passed in useSelector from counterslice
  const count = useSelector((state) => state.counter.value); //state.counter.value //state //state.counter
  const counterObject = useSelector((state) => state.counter);
  const secondaryCounter = useSelector((state) => state.counter.secondaryCounter);
  const name = useSelector((state) => state.counter.name);
  const lastName = useSelector((state) => state.counter.lastName);
  console.log("count", count, secondaryCounter, name, lastName);
  console.log("counterObject", counterObject);
  console.log("secondaryCounter", secondaryCounter);

  const characterObject = useSelector((state) => state.character);
  console.log("characterName", characterObject);

  //Step 2 for updating store values : write dispatch variable 
  const dispatch = useDispatch();

  
  const [incrementAmount, setIncrementAmount] = useState('2');

  const incrementValue = Number(incrementAmount) || 0;

  //sharing data between 2 components
  // return (
  //   <div>
  //     <h1>character name : {characterObject.characterName}</h1>
  //   </div>
  // );

  return (
    <div>
      <div className={styles.row}>
        <button
          className={styles.button}
          aria-label="Decrement value"
          onClick={() => dispatch(decrement())}
        >
          Decrement
        </button>
        <span className={styles.value}>{count}</span>
        <button
          className={styles.button}
          aria-label="Increment value"

          onClick={() => dispatch(increment())}
        >
          Increment
        </button>
      </div>
      {/* <div className={styles.row}>
        <input
          className={styles.textbox}
          aria-label="Set increment amount"
          value={incrementAmount}
          onChange={(e) => setIncrementAmount(e.target.value)}
        />
        <button
          className={styles.button}
          onClick={() => dispatch(incrementByAmount(incrementValue))}
        >
          Add Amount
        </button>
        <button
          className={styles.asyncButton}
          onClick={() => dispatch(incrementAsync(incrementValue))}
        >
          Add Async
        </button>
        <button
          className={styles.button}
          onClick={() => dispatch(incrementIfOdd(incrementValue))}
        >
          Add If Odd
        </button>
      </div> */}
    </div>
  );
}
