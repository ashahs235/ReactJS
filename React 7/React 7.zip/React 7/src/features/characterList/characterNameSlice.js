
//Step 0 : Import Createslice from redux tool kit
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { fetchCount } from '../counter/counterAPI';

//step 1
const initialState = {
  //characterName: "",
  characterName: "Winchel",
  secondaryCharacterName : "",
  universe : "Galaxy",
  mainVillain : "",
  movieName : "",
};

//step 2
export const characterNameSlice = createSlice({
    name: "characterName", //any name
    initialState: initialState,
    //initialState, (=initialState: initialState)
    //OR
    //if name of a variable (const initialstate) & key are same : write once initialState
    //initialState : initialState,
    // initialState: {
    //   value:0,
    // },
   //initialState to declare var -- like state variable (state var can be manipulated by React App) in useState hook
  
    //reducers are functions which update or maipulate value in some way
    reducers: {
      //this increment is a method which is responsible when + button in UI is clicked
      /*addCharacter: (state, characterName) => {
        console.log("state", state.value); 
        state.characterName = characterName; */

        //state, characterName r the values/data passed in the reducer
        updateCharacter: (state, charName) => {
          console.log("state", state, charName);  //state.value
          console.log("state details", state.secondaryCharacterName, charName.payload); 
          //state.secondaryCharacterName is empty, so visible as empty
          
          state.secondaryCharacterName = charName.payload;
      },
      updateVillain : (state, villainObject) => {
        console.log(state.mainVillain, villainObject);
        console.log(villainObject);
        state.mainVillain = villainObject.payload;
      },

      updateMovieName : (state, movieObject) => {
        console.log(state.movieName, movieObject);
        state.movieName = movieObject.payload;
      }
    },
  });
  
  //step 3 : expose actions from slice
  //Reducers say how to update the values
  //Actions : say when to update values -- action taking place to update the values {Reducer names inside brackets}
  export const { updateCharacter, updateVillain, updateMovieName } = characterNameSlice.actions;

  //step 4 : export the slice itself
  export default characterNameSlice.reducer;
  