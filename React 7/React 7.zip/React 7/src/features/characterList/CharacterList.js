//import {useState} from "react";
//step 1 : import useSelector hook
import { useState } from "react";

import { updateCharacter, updateVillain, updateMovieName } from "./characterNameSlice";
//step 1 for updating values : import useDispatch hook from "react-redux" pkg
import { useSelector, useDispatch } from "react-redux";

//Accessing data from Redux Store
export function CharacterList()
{
    const characterData = useSelector((state) => state.character);

    //this data is not accessed outside this component in store (slices), 
    //can't access this useState variable localDataState outside this component
    //const localDataState = useState("initial value");

    //but in redux -- data is shared among various components

    //Step 2 for updating store values : write dispatch variable 
    const dispatch = useDispatch();

    console.log(characterData);
    return (
        <div>
            <h1>Indian Premiere League</h1>
            <h1>Lead names : {characterData.characterName}</h1>
            <h1>Universe : {characterData.universe}</h1>
            <button onClick={() => dispatch(updateCharacter("Vision"))}>
                Show Side Character
            </button>
            <div>
                <h1>{characterData.secondaryCharacterName}</h1>
            </div>

            <button onClick={() => dispatch(updateVillain("Rocky"))}>
                Show Previous Villain
            </button>
            <div>
                <h1>{characterData.mainVillain}</h1>
            </div>

            <button onClick={() => dispatch(updateMovieName("KGF"))}>
                Show Movie Name
            </button>
            <div>
                <h1>{characterData.movieName}</h1>
            </div>
        </div>
    );
}