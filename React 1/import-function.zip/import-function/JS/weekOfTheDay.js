export const daysOfTheWeek = ["Sunday", "Monday", "Tuesday"]; //to be used in another file
export const monthsArray = ["Jan", "July", "Oct"];

//syntax is nameOfTheArray.map(function(){})
//parameters can be of any names but they represent (1)elements/values & (2)indexes
export function printDaysOfTheWeek()
{
    daysOfTheWeek.map(function(day, index){
        console.log(day, index);
    })
}

//anything can be exported by using a keyword export - function, array, object, string

//same func using arrow
export function printDaysOfTheWeek1()
{
    daysOfTheWeek.map((day)=>{
        console.log(day);
    })
}