//Entry File - imports are occuring - this file should be defined as a type of module

//write code in multiple files - import & export - use const
//import {daysOfTheWeek} from "./weekOfTheDay.js"; 
import {daysOfTheWeek, monthsArray, printDaysOfTheWeek, printDaysOfTheWeek1} from "./weekOfTheDay.js"; //{const(s)} import multiple constants from other file
console.log(daysOfTheWeek); //Error - Uncaught SyntaxError: Cannot use import statement outside a module - .html - type=module
console.log(monthsArray);
printDaysOfTheWeek();

//module is a parts of a project like script.js, weekOfTheDay files, large project split into multiple files 
//- so use import, export - so that single file doesn't exceed 100+ lines

printDaysOfTheWeek1();
document.getElementById("just").innerHTML = "<h1>Breakpoint</h1>"
document.getElementById("container1").innerHTML = "<h1>Hello world</h1>" //first paint cycle of the browser - execution

//document.getElementById("container1").innerHTML = "<h1>World</h1>" //next cycle 

//Debugger - line by line debugging - Sources tab -  Entire Code
//add breakpoint in Source tab & see elements tab .. Console
//hit play button (Paused in Debugger)
// 2 breakpoints - 3 paint cycles

//1000 innerHTML lines - 1000 breakpoints - 1000 paint cycles - 1000 DOM refresh items - 1000 processing steps
//FACEBOOK or Instagram - browsing through feed, stories -  everything is added as innerHTML - dynamically populating data from Server
//10000+ updates - twitter feed is simple compared to FB - many DOM updates happening in the back side of FB Browser side
//everything is innerHTML - fed up of many DOM updates - Jordan Walke suggested not to update DOMs in every cycle
//So a virtual entity is added to track d updates network performance memory application => Virtual DOM
// - doesn't exist in Browser, exists in Library called Vitual DOM
//Real DOM - actual elements r updated

//1)Virtual DOM combines 2 innerHTML stmts & makes changes in a single update cycle
//here -  in twitter, if anything (hashtag, popup happens - fetching from server takes time - makes website slow) changes, it updates only in that component & tells DOM to update only dat data, not entire DOM tree
//so load & processing time of browser is saved (Real DOM load is not there)
//2)if left sidebar & right sidebar have any changes, both are combined together by Virtual DOM in a single change cycle & pass them to a real DOM
//- changes of 2 steps is done in 1 step

//Basic mechanism of dynamic library - REACT has better performance than JQuery, Angular, Ember
//In a real React Ecosystem, 1000s of steps are combined together by Virtual DOM Entity & passed to the REAL DOM in a single event

//2 innerHTML stmts refresh internally, if 5 - 5 times refreshing inernally - Real DOM MAnipulation
//Virtual DOM combines all 5 in its internal Virtual CORE & displays in 1 cycle - Virtualization of DOM to increase/improve actual DOM functionality
//REACT CODE only in JS - 1 innerHTML, only 1 <div> in HTML file 

document.getElementById("container").innerHTML = `<div><h1>ReactJS</h1><p>FrontEnd Framework</p></div>`

//OR

const htmlElements = `<div><h1>ReactJS</h1><p>FrontEnd Framework</p></div>`;
document.getElementById("container").innerHTML = htmlElements;

//above stmt says that it's possible to develop an entire website using JS only, only one <div> root element in HTML file
//This is called JSX - Javascript XML is used to write HTML in our Code 

//Babel - library
//Create REACT App - npx create-react-app my-app, cd my-app, npm start - automatic folder structure
//Terminal - reactJS