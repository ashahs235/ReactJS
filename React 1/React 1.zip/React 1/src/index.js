//import React libraries

import React from 'react'; //'react' is a pkg in node_modules
import ReactDOM from 'react-dom'; //this library is responsible to throw changes from Virtual DOM to Real DOM

//define variable - create code for Virtual DOM - single line of Code
const leftSideBar = <div>Left sidebar of Social Media 2</div>; //changes made is reflected in virtual dom (console) & not real dom(browser)

const rightSideBar = <div>Right sidebar</div>;

const feedComponent = <p>Tweets Feed</p>;

console.log(leftSideBar, feedComponent); //Object - JSON - virtual DOM, elements - real DOM - Babel Compiler

//to print on real DOM - Browser - render is a function that converts Virtual DOM to Real DOM - process is rendering
//inbuild method - 1st parameter is object, 2nd is accessing id to print in real DOM/browser without using innerHTML or innerText

//render those variables, parameters are element, address of d div
//ReactDOM.render(leftSideBar, document.getElementById("root")); //instead of innerHTML

//Console is virtual DOM
//Browser is REAL DOM
//Steps - 1) import libraries 2) create code for Virtual DOM 3) render that virtual DOM in the real DOM

//Developing React Components - function returning HTML tag
function App()
{
    //returning a HTML markup in a React project is called JSX - JavaScript XML 
    //- HTML within JS is JSX - HTML tags written in a function or after a variable in react project is called JSX syntax
    return <div>APP Component</div>; //return 1, 2, "test"
    //Return Syntax is bcoz in React, html code should not be written in .html file, it has to be written in .js file bcoz 
    //bcoz of virtual DOM representation - babel io repl right side by react compiler - ui in js bcoz if there 
    //are any changes in JS code, JS gets to know the changes in which HTML element
}

//ReactDOM.render(<App/>, document.getElementById("root"));

//Returning Multiple div elements through one variable - Functional Components - writing collection of HTML elements together 
function FunctionalApp() //JSX syntax - error for functionalApp() - multiple div or html elements should be written
{
    return(
        <div>
            <div>
                
            </div>
            <p>Hello Friends</p>
            <p>Welcome to</p>
            <p>Programming Class</p>
        </div>

        
    ); //copy paste in babel - 
}
ReactDOM.render(<FunctionalApp/>, document.getElementById("root"));

//html elements must be passed in virtual DOM instead of real DOM - so html in js file - import, define markup, render
