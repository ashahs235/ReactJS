export function Header(props) {
  // console.log(props);
   console.log(props.cartItems);

  return (
    <nav className="navbar navbar-light bg-primary">
      {/* width, white text - text light */}
      <div className="text-center w-100 text-light d-flex">
        <div className="w-100">Shopping Cart by using Props..</div>
        <div className="d-flex me-5 align-items-center">
          <i className="fa fa-shopping-cart ms-auto me-2" />
          {props.cartItems.length}
        </div>
      </div>
    </nav>
  );
}
