import productsJSON from "./products.json"; //productsJSON can be any name

export function Products(props) {
  // console.log(props);

  function addToCartClickHandler(productItem) {
    // console.log("Add to Cart Clicked", productItem);
    // console.log("Props values are", props);
    // const tempCartItemsArray = props.cartItems;
    // tempCartItemsArray.push(productItem);
    // console.log("tempCartItemsArray value", tempCartItemsArray);
    // props.updateCartItems(tempCartItemsArray); //--doesn't work

    const updateCartItems = props.updateCartItems;
    const cartItemsProps = props.cartItems;
    //setMyArray(oldArray => [...oldArray, newElement]);
    //passing new item in old array - destructuring/spread syntax in JS
    //... is old array, productItem is new item of the array
    updateCartItems(() => [...cartItemsProps, productItem]);
  }

  // console.log(productsJSON);
  // console.log(productsJSON.result);

  //can't say that productsJSON can come for API Call - Server,
  //if error - productsJSON - so if condition below
  function renderProducts() {
    if (productsJSON !== undefined) {
      //loop - map function - returns card twice
      //y not for loops - store & render
      //map funct iterates & returns array -
      //iterated JSON array & returned another array of card items - HTML Code
      //map func returns HTML Code as many times items r present in JSON file
      //inspect & see HTML elements - 3 <div> mt-4
      return productsJSON.result.map(function (productItem, item1) {
        //console.log(productItem, item1);
        return (
          <div className="mt-4" key={productItem.name}>
            <div className="card" style={{ width: "18rem" }}>
              <div className="card-body">
                <h5 className="card-title">{productItem.name}</h5>
                <p className="card-text">Price : {productItem.price}</p>
                <button
                  className="btn btn-primary"
                  onClick={() => addToCartClickHandler(productItem)}
                >
                  Add to Cart
                </button>
              </div>
            </div>

            {/* <div>{productItem.name}</div>
            <div>{productItem.price}</div> */}
          </div>
        );
      });
      //function needs to return anything for it to be a component
      // return (
      //   <div>
      //     <h1>Function Return</h1>
      //   </div>
      // ); //return map
    }
  }

  return (
    <div
      className="d-flex w-100 justify-content-center 
    align-items-center mt-5"
    >
      {/* <h1>Products</h1> */}
      {renderProducts()}
    </div>
  );
}
