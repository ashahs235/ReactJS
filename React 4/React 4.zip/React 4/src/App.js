import { useState } from "react";
import { Header } from "./Components/Header.js";
import { Products } from "./Components/Products.js";
 function App() {
  const [cartItems, updateCartItems] = useState([]);
  return (
    <div className="App">
      <Header cartItems={cartItems} />
      <Products updateCartItems={updateCartItems} cartItems={cartItems}/>
    </div>
  );
}

export default App;


