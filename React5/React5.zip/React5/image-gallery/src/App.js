//any hooks - 1st line
import {useEffect, useState} from "react";
import './App.css';
import axios from "axios";
function App() 
{

  // function getData()
  // {
  //    axios.get('https://picsum.photos/v2/list')
  //   .then(function (response) {
  //     // handle success
  //     console.log(response.data);
  //   })
  //   .catch(function (error) {
  //     // handle error
  //     console.log(error);
  //   });
  // }

  const[imagesRendered, updateImagesRendered] = useState([]);

  function renderImages(responseData)
  {
    console.log("Data passed", responseData);

    //declare hook
    const imagesArray = responseData.map((imageObject) => {
      console.log(imageObject); //individual objects/entries
      const imageUrl = imageObject.download_url;
      const name = imageObject.author;
      return(
        <div>
          <h1>{name}</h1>
          <img src={imageUrl} width="200"/>
        </div>
      );
    });
    updateImagesRendered(imagesArray); //useState var imagesRendered is updated

  //   const numbersArray = [1, 2, 3, 4];
  //   console.log("numbersArray", numbersArray);
  // const newArray = numbersArray.map((number) => {
  //   return number * 2;
  // }); //map gives updated array
  // console.log("new Array is", newArray);
  }

  async function getData()
  {
     const response = await axios.get('https://picsum.photos/v2/list');
     console.log(response.data);

     //to display pics on d website

     renderImages(response.data); 
  }

  // axios.get('https://picsum.photos/v2/list')
  // .then(function (response) {
  //   // handle success
  //   console.log(response.data);
  // })
  // .catch(function (error) {
  //   // handle error
  //   console.log(error);
  // });


  useEffect(() => {
    console.log("This is called once");
    //write axios inside useEffect
    getData();
    //renderImages();
  }, []);
  return (
    <div className="App">{imagesRendered}</div> 
  );
}

export default App;
