import './App.css';
import {useState, useEffect} from "react";

let born = false;

function App() {

  //state variable
  const [growth, updateGrowth] = useState(0);
  const [nirvana, updateNirvana] = useState(false); //3rd stage of useEffect
  //console.log(growth); //creation stage, update/render/mid stage - clk button - values r changing
  //button click handler
  function handleGrowthButtonClick()
  {
    //console.log("Growth button clicked");
    updateGrowth(growth + 10); //0* wrong -- useState(1)
  }

  useEffect(() => {
    console.log("Current Nirvana value", nirvana, growth);
    document.title = "Nirvana attained";
  }, [nirvana]);  //... is wrong

  //Functions written inside map functions are called callback functions in JS -- Javascript callbacks
  //map-iterating function- function is passed as a parameter in map function
  // Array.map(() => {})
  // Array.map(function(){

  // }) 

  //Similarly useEffect hook passes a function as a parameter - 
  //it's a effect callback func passed by useEffect hook internally -> ctrl+clk-dependencies

  //Lifecycle of a React Component - 3 major stages
  //Each component in React has a lifecycle which you can monitor and manipulate during its three main phases. 
  //The three phases are: Mounting, Updating, and Unmounting.

  //1) Initialization or Creation/create stage - component is created - variables are created
  //2) Mid stage or render cycles - render calls r running - return code is displayed in d browser
  //2- making use of those variables to make changes in the page
  //3) destroy stage - close d browser - page is destroyed - browser cleans d variables

  //When class is created - pass dependencies in useEffect 2nd parameter - now empty array
  //dependencies - dependent variable on d basis of which useEffect hook is running
  //Empty Array as a second parameter
  //called when a component is created first time
  //comment for practical case
  //3 variations of useEffect - 1)empty array as a 2nd parameter-runs only during component creation, 
  useEffect(() => {
    //console.log("Component is born", growth); //create stage - no change in value - useEffect runs only once - used to fetch API calls for server only once
    document.title = "Component Born"; //--
  }, []); //2nd parameter is empty


  //3 variations of useEffect - 2)nothing is passed in 2nd parameter - useEffect hook will run evrytime any change occurs(state variable changes)
  useEffect(() => {
   // console.log("Component is growing"); //printed directly, clk 2nd tym
  });

  // useEffect(() => {
  //   console.log("current value of born", born);
  //   if(born === true)
  //   {
  //     console.log("Component is growing", growth); //printed onClick
  //     document.title = "Component is growing";//-- //if there's no if condn, born isn't seen in title, directly growing
  //   }
  //   else
  //   {
  //     born = true;
  //   }
  // });

  //3 variations of useEffect - 3) to make d component die - nirvana after 60 years - create a new variable
  useEffect(() => {
    //console.log("current value of born", born);
    if(born === true)
    {
      //console.log("Component is growing", growth, nirvana); //printed onClick
      //document.title = "Component is growing";//-- //if there's no if condn, born isn't seen in title, directly growing
      if(growth > 60)
      {
        updateNirvana(true);
      }

      //to change tab name to nirvana attained after 60 years
      else
      {
        document.title = "Component is growing"; 
      }

      // else if(growth > 18)
      // {
      //   updateNirvana(true);
      // }
      // else
      // {
      //   updateNirvana(false);
      // }
    }
    else
    {
      born = true;
    }
  });


  //Dependencies - 3rd variation - variable is passed - useEffect is dependent on dat var & is called when dat var changes
  //nirvana changes from nothing to false, 60 - true
  //empty array, no array, pass a state variable in second parameter array
  // useEffect(() => {
  //   console.log("Current Nirvana value", nirvana, growth);
  //   document.title = "Nirvana attained";
  // }, [nirvana]); //[nirvana, growth]); --any change in these variables, useEffect func stmt gets called

  //rendering code
  return (
    <div className="App">
      <header className="App-header">
        <h3>{growth} years</h3>
        <button onClick={() => handleGrowthButtonClick()}>
          <h4>Update Growth</h4>
        </button>
      </header>
    </div>
  );
}

export default App;
