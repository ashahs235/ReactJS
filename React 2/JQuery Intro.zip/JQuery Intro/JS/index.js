//Regular JavaScript - Vanilla JS (no library/framework)- to access id
//document.getElementById("root").innerText = "Hello World";
//document.querySelector("#root").innerHTML = "<h1>Hello Friends</h1>";
//document.querySelector(".root-class").innerHTML = "<h1>Hello Friends</h1>";
const buttonElement = document.getElementById("open-alert");

function openAlert()
{
    alert("Hello World");
}
//const buttonElement = document.getElementById("open-alert"); //2 lines
//buttonElement.addEventListener("click", openAlert);

//Using JQuery - to access id
//$("#root").html("<h1>Welcome to Programming World<h1>"); //works without tags too - jquery syntax for above 2, 3 lines.. 6-10

console.log($("#open-alert"));

//.on - eventHandler

$("#open-alert").on("click", openAlert); //10,11 -> 2 lines of JS = 1 line of JQuery

//$("#root").text("Coding"); //instead of innerHTML JS
$(".root-class").html("<h1>Codingground</h1>"); //don't use upper case
//