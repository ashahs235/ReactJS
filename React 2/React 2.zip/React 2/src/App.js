import './App.css';
import {useState} from 'react';
//Functional Component - HTML Code is written in a function - 
//opening & closing tags are must including <br> (unclosed even in normal HTML),
//All HTML tags should be wrapped in parent tag, write className (in React) later - class Attribute
//no different CSS folder, we write componentName.css - import
//if class - shows warning in console, later const
//variables can be used in any tag, in JS var only in <script>
//State means variable defined in React Code whose value should be updated in future - 1:56
//state variables - dynamically updated in React Code - built in func is useState() - built in functions are called Hooks for some functionality

//html onclick, React onClick, in browser click on d button multiple times

function App() {
  //define variables, use them using {}
  const user = "Developer";
  const role = "Top 1 designation"; //any no of variables

  const inputText = "";

  //const count = 0; //normal variable defining
  //console.log(count);

  //to make the variable dynamic or stateVariable
  //state variable & function to update (+, -) the state variable - array notation syntax
  const [count, updateCount] = useState(5); //1, 2.. updating this value on some event - function updateCount, state variable & updater func
  //count is value of a variable, updateCount is an event
  //console.log("Value of hook is", count);

  const [userName, updateUserName] = useState("Joe");

  const [fruit, updateFruitName] = useState("Apple");

  const [postStatus, updatePostStatus] = useState("uploading");

  function handleButtonClick()
  {
    console.log("button Click event");
    updateCount(count * 2); //count+1, -, double=*2
    alert("Hello World");
  }

  function handleUserButtonClick()
  {
    console.log("Update button clicked");
    updateUserName("SuperMan");
  }

  function handleFruitValueClick()
  {
    updateFruitName("Watermelon");
  }

  function handleCompleteUpload()
  {
    updatePostStatus("Image successfully uploaded");
  }

  return (
    <div>
    <div className="container"> 

    <p>The current value is {count}</p>

      <h1>Website Title</h1> 
      <h1>{`Hello ${user}`}</h1>
      <h1>user</h1>
      <h1>{user} is a {role}</h1>

    <button onClick={handleButtonClick}>button Func</button>

    <button onClick={() => updateCount(count*2)}>Update</button>

    <button
    onClick={function()  {console.log("Button")} }>Button
    </button>

    <button
      onClick = {()=> { 
        console.log("button clicked");
      }}>Increment value
    </button>

      <div className="container">
      <p>The current username is {userName}</p>
      <button onClick={handleUserButtonClick}>Update Username</button>

      
      <p>The current fruit is {fruit}</p>
      <button onClick={handleFruitValueClick}>Update Fruit</button>
      
      <div>
        <p>{postStatus}</p>
        <button onClick={handleCompleteUpload}>Update Completed</button>
      </div>

      </div>

      
      

    <h1>
      
      <label>User Name : </label>
      <input type="text" />

    </h1>

    <p>
      {inputText}

    </p>

      <em>Site Description</em><br></br>
      <i>Hello</i><br></br>
      <a href="https://www.w3schools.com">w3schools</a>
      </div>
      <footer className="footer">This is a Footer</footer> 
    </div>  
  //not this way
  // <h1>Hi</h1>
  // <p>hello</p>
  );  
}



export default App; 
