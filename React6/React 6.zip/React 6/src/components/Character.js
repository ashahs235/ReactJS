import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
export function Character()
{
    const [charactersArray, updateCharactersArray] = useState([]);
    async function getCharacters()
    {
        const responseObject = await axios.get("https://rickandmortyapi.com/api/character");
        //console.log(responseObject);
        //console.log(responseObject.data.results); 
        updateCharactersArray(responseObject.data.results); //results from API gets stored in charactersArray
    }
    useEffect(() => {
        getCharacters();
    }, []);

    //
    function renderCharacters()
    {
        //iterate an array : map - array.map(() => {})
        return charactersArray.map((characterItemJSON)=>{
            console.log(characterItemJSON); //individual JSON objects - values
            //return <div>{characterItemJSON}</div> error
            return (
                // Warning: Each child in a list should have a unique "key" prop.--key
                <div key={characterItemJSON.id}>
                    <Link to={`/character/${characterItemJSON.id}`}>
                        <h1>{characterItemJSON.name} - {characterItemJSON.status}</h1>
                     </Link>
                </div>);
            
        });
    }
    console.log("charactersArray is", charactersArray); //2 values - empty & updated one
    return <div>{renderCharacters()}</div>;
}