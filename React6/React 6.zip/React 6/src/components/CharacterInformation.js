import { useEffect, useState } from "react";
import axios from "axios";


export function CharacterInformation(props)
{
    //props - any data which is passed from a parent component to a child component
    console.log("Props", props);
    //200 in console
    console.log("Props match", props.match, props.match.params.characterId); //match came from react-router-dom library
    //Step 1 : make API call using useEffect
    //step 2 : Store the response from API call in a state variable
    //Step 3 : Write a render func which shows data from API call
    
    const [characterInfo, updateCharacterInfo] = useState(null); //JSON array ([]), JSON obj null or ({})

    //hook
    async function fetchCharacterInformation()
    {
        //to print particular details
        const characterId = props.match.params.characterId;
        const responseObject = await axios.get(`https://rickandmortyapi.com/api/character/${characterId}`);
        console.log("response", responseObject);
        console.log("response data", responseObject.data);
        updateCharacterInfo(responseObject.data)
    }
    useEffect(() => {
        fetchCharacterInformation();
    }, []);

    function renderCharacterInformation()
    {
        if(characterInfo != null)
        {
            console.log("character info", characterInfo);
           return (
               <div>
                   <h1>{characterInfo.name}</h1>
                   <img src={characterInfo.image} />
               </div>
           ) ;
        }
    }
    return <div>{renderCharacterInformation()}</div>; 
    // return <h1>Hi</h1>;
}