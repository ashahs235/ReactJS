import { BrowserRouter as Router, Route, Switch } from "react-router-dom"; //alias name - parent of all components
//Route : address or path : /
import { Navbar } from "./components/Navbar.js";
import { Homepage } from "./components/Homepage.js";
import { AboutUs } from "./components/AboutUs.js";
import { Character } from "./components/Character.js"; 
import { CharacterInformation } from "./components/CharacterInformation.js";
import './App.css';

//url/Character, /AboutUs - Route
//Step 1 : Import Browser Router at top level of App Component
//step 2 : Import Route & specify addresses for individual components -- go to specific page
//Step 3 : Import Switch to prevent mixing of Component
function App() {
  return (
    //for / routes -- some built in lib -- browser router component -- parent of all comp
    <Router>
      <div className="App">
        {/* <h1>React Router</h1> */}
        <Navbar/>
        <Switch>
          {/* which component at what address */}
          {/* 1st line path="/" component={Homepage} -- below stmts too homepage component is printed bcoz of matching /*/}
          {/* Switch component goes one by one - match that slash --like normal switch case - switch between components */}
          {/* if /aboutus is at d top, "/" homepage comp isn't accessed bcoz /aboutus can't be matched with / */}

          {/* Can't keep switching if many components are there -- so exact */}

          <Route path="/" component={Homepage} exact/>
          <Route path="/aboutus" component={AboutUs} />
          
          {/* stmts after path="/" can't be accessed */}
          <Route path="/character" component={Character} exact/>

          {/* bcoz of url http://localhost:3000/character/4 -- 
          that variable id gets stored in below characterId (user defined name - charId) 1, 2, 3, 4 -- colon : is for dynamic route -- add the character information component*/}
          <Route path="/character/:characterId" component={CharacterInformation} />
          {/* <AboutUs/> */}
          {/* <Homepage/>
          <Character/> */}
        </Switch>
      </div>
    </Router>
   
  );
}

export default App;
